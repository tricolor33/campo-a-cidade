let player;
let obstacles = [];
let gameOver = false;

function setup() {
  createCanvas(800, 400);
  player = new Player();

  // Criar obstáculos
  for (let i = 0; i < 5; i++) {
    obstacles.push(new Obstacle(random(300, 750), random(50, 350)));
  }
}

function draw() {
  background(120, 200, 120); // fundo verde (campo)

  // Parte da cidade
  noStroke();
  fill(180, 220, 255);
  rect(400, 0, 400, 400); // céu sobre cidade
  fill(80);
  rect(600, 200, 80, 200); // prédio 1
  rect(700, 150, 60, 250); // prédio 2

  // Linha divisória entre campo e cidade
  stroke(0);
  strokeWeight(2);
  line(400, 0, 400, height);

  if (!gameOver) {
    player.show();

    for (let obs of obstacles) {
      obs.update();
      obs.show();

      if (player.hits(obs)) {
        gameOver = true;
      }
    }

    // Verificar vitória
    if (player.x > width - 20) {
      fill(0);
      textSize(32);
      textAlign(CENTER, CENTER);
      text("Você chegou à cidade!", width / 2, height / 2);
      noLoop();
    }
  } else {
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Você bateu em um obstáculo!", width / 2, height / 2);
    noLoop();
  }
}

function keyPressed() {
  if (keyCode === UP_ARROW) {
    player.move(0, -10);
  } else if (keyCode === DOWN_ARROW) {
    player.move(0, 10);
  } else if (keyCode === RIGHT_ARROW) {
    player.move(10, 0);
  } else if (keyCode === LEFT_ARROW) {
    player.move(-10, 0);
  }
}

class Player {
  constructor() {
    this.x = 20;
    this.y = height / 2;
    this.r = 20;
  }

  move(dx, dy) {
    this.x += dx;
    this.y += dy;
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  show() {
    fill(255, 255, 0); // cor do jogador
    ellipse(this.x, this.y, this.r);
  }

  hits(obstacle) {
    let d = dist(this.x, this.y, obstacle.x, obstacle.y);
    return d < this.r / 2 + obstacle.r / 2;
  }
}

class Obstacle {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.r = 30;
    this.speed = random(1, 2);
  }

  update() {
    this.y += this.speed;
    if (this.y > height || this.y < 0) {
      this.speed *= -1;
    }
  }

  show() {
    fill(150, 75, 0); // marrom (vaca ou trator)
    ellipse(this.x, this.y, this.r);
  }
}
